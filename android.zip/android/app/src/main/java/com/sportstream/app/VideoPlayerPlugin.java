package com.sportstream.app;

import android.app.Activity;
import android.content.Intent;

import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "VideoPlayer")
public class VideoPlayerPlugin extends Plugin {

    private PluginCall savedCall;

    /**
     * Abre el reproductor nativo ExoPlayer (pantalla completa dentro de la app).
     *
     * Parámetros JS:
     *   url    : string  — URL del stream (m3u8, mpd, mp4, etc.)
     *   title  : string  — Nombre del canal/evento (opcional)
     *   referer: string  — Cabecera Referer requerida por el servidor (opcional)
     */
    @PluginMethod
    public void openStream(PluginCall call) {
        String url     = call.getString("url", "");
        String title   = call.getString("title", "SportStream");
        String referer = call.getString("referer", "");

        if (url == null || url.isEmpty()) {
            call.reject("URL vacía");
            return;
        }

        savedCall = call;

        Intent intent = new Intent(getContext(), ExoPlayerActivity.class);
        intent.putExtra(ExoPlayerActivity.EXTRA_URL,     url);
        intent.putExtra(ExoPlayerActivity.EXTRA_TITLE,   title);
        intent.putExtra(ExoPlayerActivity.EXTRA_REFERER, referer);

        startActivityForResult(call, intent, "handleExoPlayerResult");
    }

    @ActivityCallback
    private void handleExoPlayerResult(PluginCall call, ActivityResult result) {
        if (call == null) return;

        if (result.getResultCode() == Activity.RESULT_CANCELED) {
            // La Activity devolvió un error
            String error = "";
            if (result.getData() != null) {
                error = result.getData().getStringExtra("error");
                if (error == null) error = "";
            }
            JSObject ret = new JSObject();
            ret.put("closed", true);
            ret.put("error", error);
            call.resolve(ret);
        } else {
            // Cerrado normalmente
            JSObject ret = new JSObject();
            ret.put("closed", true);
            ret.put("error", "");
            call.resolve(ret);
        }
    }
}
