package com.sportstream.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

import java.util.HashMap;
import java.util.Map;

@OptIn(markerClass = UnstableApi.class)
public class ExoPlayerActivity extends AppCompatActivity {

    public static final String EXTRA_URL     = "url";
    public static final String EXTRA_TITLE   = "title";
    public static final String EXTRA_REFERER = "referer";

    private ExoPlayer  player;
    private PlayerView playerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Pantalla completa, sin barra de estado
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setContentView(R.layout.activity_exoplayer);

        Intent intent = getIntent();
        String url     = intent.getStringExtra(EXTRA_URL);
        String title   = intent.getStringExtra(EXTRA_TITLE);
        String referer = intent.getStringExtra(EXTRA_REFERER);
        if (referer == null) referer = "";

        // Título
        TextView tvTitle = findViewById(R.id.exo_title);
        if (tvTitle != null && title != null) tvTitle.setText(title);

        // Botón cerrar
        ImageButton btnClose = findViewById(R.id.exo_close);
        if (btnClose != null) {
            btnClose.setOnClickListener(v -> {
                setResult(RESULT_OK);
                finish();
            });
        }

        // Botón físico Atrás (API moderna, sin deprecated)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                setResult(RESULT_OK);
                finish();
            }
        });

        // Configurar DataSource con las cabeceras que el servidor exige
        DefaultHttpDataSource.Factory dsFactory = new DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 " +
                          "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
            .setAllowCrossProtocolRedirects(true);

        if (!referer.isEmpty()) {
            Map<String, String> headers = new HashMap<>();
            headers.put("Referer", referer);
            android.net.Uri ru = android.net.Uri.parse(referer);
            String origin = (ru.getScheme() != null && ru.getAuthority() != null)
                ? ru.getScheme() + "://" + ru.getAuthority()
                : referer.replaceAll("/$", "");
            headers.put("Origin", origin);
            dsFactory.setDefaultRequestProperties(headers);
        }

        // Construir ExoPlayer con la factory configurada
        player = new ExoPlayer.Builder(this)
            .setMediaSourceFactory(new DefaultMediaSourceFactory(dsFactory))
            .build();

        playerView = findViewById(R.id.exo_player_view);
        playerView.setPlayer(player);
        playerView.setKeepScreenOn(true);

        // Cargar y reproducir el stream
        MediaItem mediaItem = MediaItem.fromUri(url);
        player.setMediaItem(mediaItem);
        player.prepare();
        player.setPlayWhenReady(true);

        // Manejo de errores — devuelve el error a JavaScript
        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(@NonNull PlaybackException error) {
                Intent result = new Intent();
                result.putExtra("error", error.getMessage());
                setResult(RESULT_CANCELED, result);
                finish();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (player != null) player.play();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
