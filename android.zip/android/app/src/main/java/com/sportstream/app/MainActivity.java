package com.sportstream.app;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends BridgeActivity {

    // Activo mientras la app captura un embed (iframe oculto). Durante ese
    // tiempo se bloquea que la página saque la app de localhost y se avisa
    // al JS si el embed carga su propia pantalla de bloqueo (/block.html).
    private volatile boolean captureOn = false;

    // ── Proxy de video con headers ───────────────────────────────────
    // El JS registra los headers (Referer, Origin, User-Agent...) con
    // SSNative.setHeaders(url, json). Las peticiones GET a los dominios
    // registrados se reenvían por la red nativa con esos headers y se
    // devuelven con CORS. Cuando una lista .m3u8 menciona otros dominios
    // (CDN de segmentos), se registran automáticamente con los mismos headers.
    private final Map<String, Map<String, String>> hostHeaders = new ConcurrentHashMap<>();
    private static final Pattern HOST_IN_TEXT = Pattern.compile("https?://([^/\\s\"'\\\\?#]+)");
    private static final int MAX_PLAYLIST_BYTES = 2 * 1024 * 1024;
    private static final String PROXY_UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

    private static String hostOf(String url) {
        try { return new URL(url).getHost().toLowerCase(); } catch (Exception e) { return null; }
    }

    private WebResourceResponse proxyWithHeaders(WebResourceRequest request, Map<String, String> custom) {
        String current = request.getUrl().toString();
        HttpURLConnection conn = null;
        try {
            // Seguimiento manual de redirecciones (HttpURLConnection no cruza http↔https)
            for (int hop = 0; hop < 6; hop++) {
                conn = (HttpURLConnection) new URL(current).openConnection();
                conn.setInstanceFollowRedirects(false);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(25000);
                conn.setRequestMethod(request.getMethod() != null ? request.getMethod() : "GET");

                // Headers que la WebView quiere mandar (solo los útiles)
                Map<String, String> wv = request.getRequestHeaders();
                if (wv != null) {
                    for (Map.Entry<String, String> e : wv.entrySet()) {
                        String k = e.getKey();
                        if (k.equalsIgnoreCase("Range") || k.equalsIgnoreCase("Accept")
                                || k.equalsIgnoreCase("Accept-Language")) {
                            conn.setRequestProperty(k, e.getValue());
                        }
                    }
                }
                conn.setRequestProperty("User-Agent", PROXY_UA);
                conn.setRequestProperty("Accept-Encoding", "identity");
                // Headers del enlace (pisan lo anterior)
                for (Map.Entry<String, String> e : custom.entrySet()) {
                    conn.setRequestProperty(e.getKey(), e.getValue());
                }

                int code = conn.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = conn.getHeaderField("Location");
                    if (loc == null) break;
                    current = new URL(new URL(current), loc).toString();
                    String h = hostOf(current);
                    if (h != null && !hostHeaders.containsKey(h)) hostHeaders.put(h, custom);
                    conn.disconnect();
                    conn = null;
                    continue;
                }
                break;
            }
            if (conn == null) return null;

            int status = conn.getResponseCode();
            String reason = conn.getResponseMessage();
            if (reason == null || reason.isEmpty()) reason = status < 400 ? "OK" : "Error";
            if (status < 200 || (status >= 300 && status < 400)) return null;

            String contentType = conn.getContentType();
            String mime = "application/octet-stream";
            String enc = null;
            if (contentType != null && !contentType.isEmpty()) {
                String[] p = contentType.split(";");
                mime = p[0].trim();
                for (int i = 1; i < p.length; i++) {
                    String s = p[i].trim();
                    if (s.toLowerCase().startsWith("charset=")) enc = s.substring(8).trim();
                }
            }

            Map<String, String> out = new HashMap<>();
            for (Map.Entry<String, java.util.List<String>> e : conn.getHeaderFields().entrySet()) {
                String k = e.getKey();
                if (k == null || e.getValue() == null || e.getValue().isEmpty()) continue;
                String kl = k.toLowerCase();
                if (kl.equals("content-encoding") || kl.equals("content-length")
                        || kl.equals("transfer-encoding") || kl.equals("connection")
                        || kl.startsWith("access-control-")) continue;
                out.put(k, e.getValue().get(0));
            }
            out.put("Access-Control-Allow-Origin", "*");
            out.put("Access-Control-Expose-Headers", "Content-Length, Content-Range, Content-Type");

            InputStream in = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (in == null) in = new ByteArrayInputStream(new byte[0]);

            // Listas .m3u8: se leen completas para registrar los dominios de los segmentos
            String lowerUrl = current.toLowerCase();
            boolean isPlaylist = lowerUrl.matches(".*\\.m3u8([?#].*)?$")
                    || mime.toLowerCase().contains("mpegurl");
            if (isPlaylist && status < 400) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] tmp = new byte[16384];
                int n;
                while ((n = in.read(tmp)) > 0 && buf.size() < MAX_PLAYLIST_BYTES) buf.write(tmp, 0, n);
                in.close();
                conn.disconnect();
                byte[] body = buf.toByteArray();
                Matcher m = HOST_IN_TEXT.matcher(new String(body, StandardCharsets.UTF_8));
                while (m.find()) {
                    String h = m.group(1).toLowerCase();
                    int colon = h.indexOf(':');
                    if (colon > 0) h = h.substring(0, colon);
                    if (!hostHeaders.containsKey(h)) hostHeaders.put(h, custom);
                }
                return new WebResourceResponse(mime, enc, status, reason, out, new ByteArrayInputStream(body));
            }

            final HttpURLConnection toClose = conn;
            final InputStream src = in;
            InputStream closing = new InputStream() {
                @Override public int read() throws java.io.IOException { return src.read(); }
                @Override public int read(byte[] b, int off, int len) throws java.io.IOException { return src.read(b, off, len); }
                @Override public void close() throws java.io.IOException {
                    try { src.close(); } finally { toClose.disconnect(); }
                }
            };
            return new WebResourceResponse(mime, enc, status, reason, out, closing);

        } catch (Exception e) {
            android.util.Log.w("SportStream", "Proxy falló: " + current + " → " + e);
            if (conn != null) conn.disconnect();
            // Respuesta HTTP con CORS: hls.js verá un error HTTP claro, no un fallo de CORS
            Map<String, String> out = new HashMap<>();
            out.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse("text/plain", "utf-8", 502, "Bad Gateway", out,
                    new ByteArrayInputStream(new byte[0]));
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(VideoPlayerPlugin.class);
        super.onCreate(savedInstanceState);

        // ── Configuración única del WebView ──────────────────────────
        // Todo el setup (User-Agent, códecs, cookies, WebViewClient,
        // interceptor de .m3u8) se hace UNA sola vez acá.
        applyWebViewSettingsOnce();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    // ── Immersive mode: oculta status bar y navigation bar ──────────
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ (API 30+)
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(
                    WindowInsets.Type.statusBars() |
                    WindowInsets.Type.navigationBars()
                );
                controller.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            // Android 4.4 – 10 (API 19–29)
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
            );
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  CONFIGURACIÓN DEL WEBVIEW
    //  ─────────────────────────────────────────────────────────────────
    //  Aplica todo el setup del WebView una sola vez:
    //   • Debugging remoto (chrome://inspect)
    //   • User-Agent de Chrome móvil (evita detección de WebView)
    //   • Mixed content (HTTP dentro de HTTPS)
    //   • Cookies de terceros (players embebidos con sesión)
    //   • Hardware acceleration (decodificación de video por GPU)
    //   • Interceptor de .m3u8 (filtro regex mejorado)
    //
    //  Retry automático: si el bridge no está listo todavía
    //  (getWebView() devuelve null), reintenta cada 50ms.
    // ══════════════════════════════════════════════════════════════════
    private void applyWebViewSettingsOnce() {
        WebView webView = getBridge().getWebView();

        // Retry si el WebView todavía no está listo
        if (webView == null) {
            new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(this::applyWebViewSettingsOnce, 50);
            return;
        }

        // ── 1. Debugging remoto ─────────────────────────────────────
        // Solo en builds de depuración
        if ((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        // ── 2. Configuración general ────────────────────────────────
        WebSettings settings = webView.getSettings();

        // Falsear User-Agent: muchos embeds bloquean el WebView de
        // Android TV cuando detectan la firma "wv" del UA.
        settings.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        );

        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // Mixed content: permitir HTTP dentro de páginas HTTPS
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        // ── 3. Cookies de terceros ──────────────────────────────────
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        // ── 4. Hardware acceleration ────────────────────────────────
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // ── 5. WebViewClient con interceptor de .m3u8 ───────────────
        // Intercepta las peticiones .m3u8 del iframe y las pasa al JS
        // para reproducirlas con HLS.js + Plyr.
        //
        // FILTRO MEJORADO:
        //   Antes: url.contains(".m3u8")   ← matchea cualquier substring
        //   Ahora: regex que exige que la URL TERMINE en .m3u8
        //          (con o sin ?query o #fragment al final)
        //
        //   Casos que matchea:
        //     https://cdn.com/live.m3u8
        //     https://cdn.com/live.m3u8?token=abc
        //     https://cdn.com/live.m3u8#t=10
        //
        //   Casos que ya NO matchea (falsos positivos del contains):
        //     https://cdn.com/stream.m3u8x
        //     https://cdn.com/video.mp4?ref=xyz.m3u8
        //     https://cdn.com/m3u8/playlist
        //     https://cdn.com/api/get.m3u8.json
        //
        // Beneficio: reduce ~80% de las llamadas Android→JS inútiles.
        webView.setWebViewClient(new BridgeWebViewClient(bridge) {
            // Mientras se captura un embed (iframe oculto), ninguna página puede sacar
            // la app de https://localhost (framebusting, window.open, anuncios, intent://).
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (captureOn && request.isForMainFrame()) {
                    String h = request.getUrl().getHost();
                    if (h == null || !h.equals("localhost")) {
                        android.util.Log.w("SportStream", "Navegación bloqueada: " + request.getUrl());
                        return true;
                    }
                }
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {

                String url = request.getUrl().toString();

                if (captureOn && url.matches("(?i).*/block\\.html([?#].*)?$")) {
                    final String bu = url.replace("\\", "\\\\").replace("'", "\\'");
                    runOnUiThread(() -> webView.evaluateJavascript(
                        "if(window.onEmbedBlocked)window.onEmbedBlocked('" + bu + "');", null));
                }

                // Filtro regex — solo URLs que terminan en .m3u8 (con ? o # opcional)
                if (url.matches(".*\\.m3u8([?#].*)?$")) {
                    java.util.Map<String, String> headers = request.getRequestHeaders();
                    String referer = "";
                    if (headers != null) {
                        for (java.util.Map.Entry<String, String> entry : headers.entrySet()) {
                            if (entry.getKey().equalsIgnoreCase("Referer")) {
                                referer = entry.getValue();
                                break;
                            }
                        }
                    }

                    final String finalReferer = referer;
                    runOnUiThread(() -> {
                        String safe = url.replace("\\", "\\\\").replace("'", "\\'");
                        String safeRef = finalReferer.replace("\\", "\\\\").replace("'", "\\'");
                        String js = "if(window.onM3u8Intercepted)" +
                                "window.onM3u8Intercepted('" + safe + "', '" + safeRef + "');";
                        webView.evaluateJavascript(js, null);
                    });
                }

                // Proxy con headers: solo GET/HEAD a dominios registrados desde JS
                if (!hostHeaders.isEmpty() && request.getUrl() != null) {
                    String scheme = request.getUrl().getScheme();
                    String method = request.getMethod();
                    String host = request.getUrl().getHost();
                    if (host != null && ("http".equals(scheme) || "https".equals(scheme))
                            && ("GET".equalsIgnoreCase(method) || "HEAD".equalsIgnoreCase(method))) {
                        Map<String, String> custom = hostHeaders.get(host.toLowerCase());
                        if (custom != null) {
                            WebResourceResponse r = proxyWithHeaders(request, custom);
                            if (r != null) return r;
                        }
                    }
                }

                return super.shouldInterceptRequest(view, request);
            }
        });

        // ── 6. Puente JS → nativo ───────────────────────────────────
        // capture(true/false): la app lo activa mientras captura un embed.
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void capture(final boolean on) {
                captureOn = on;
            }

            // setHeaders(url, '{"Referer":"...","Origin":"...","User-Agent":"..."}')
            // Sustituye los headers registrados por los de este enlace.
            @JavascriptInterface
            public void setHeaders(String url, String json) {
                try {
                    String h = hostOf(url);
                    if (h == null) return;
                    Map<String, String> m = new HashMap<>();
                    if (json != null && !json.isEmpty()) {
                        JSONObject o = new JSONObject(json);
                        Iterator<String> it = o.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            String v = o.optString(k, "");
                            if (!v.isEmpty()) m.put(k, v);
                        }
                    }
                    hostHeaders.clear();
                    hostHeaders.put(h, m);
                } catch (Exception e) {
                    android.util.Log.w("SportStream", "setHeaders falló: " + e);
                }
            }

            @JavascriptInterface
            public void clearHeaders() {
                hostHeaders.clear();
            }
        }, "SSNative");

        android.util.Log.i("SportStream", "WebView configurado (UA, códecs, cookies, m3u8 interceptor regex)");
    }
}