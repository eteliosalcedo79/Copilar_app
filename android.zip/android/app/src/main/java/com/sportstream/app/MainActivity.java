package com.sportstream.app;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;

public class MainActivity extends BridgeActivity {

    // Activo mientras la app captura un embed (iframe oculto). Durante ese
    // tiempo se bloquea que la página saque la app de localhost y se avisa
    // al JS si el embed carga su propia pantalla de bloqueo (/block.html).
    private volatile boolean captureOn = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(VideoPlayerPlugin.class);
        super.onCreate(savedInstanceState);

        // ── Configuración única del WebView ──────────────────────────
        // Todo el setup (User-Agent, códecs, cookies, WebViewClient,
        // interceptor de .m3u8) se hace UNA sola vez acá.
        applyWebViewSettingsOnce();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    // ── Immersive mode: oculta status bar y navigation bar ──────────
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ (API 30+)
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(
                    WindowInsets.Type.statusBars() |
                    WindowInsets.Type.navigationBars()
                );
                controller.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            // Android 4.4 – 10 (API 19–29)
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
            );
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  CONFIGURACIÓN DEL WEBVIEW
    //  ─────────────────────────────────────────────────────────────────
    //  Aplica todo el setup del WebView una sola vez:
    //   • Debugging remoto (chrome://inspect)
    //   • User-Agent de Chrome móvil (evita detección de WebView)
    //   • Mixed content (HTTP dentro de HTTPS)
    //   • Cookies de terceros (players embebidos con sesión)
    //   • Hardware acceleration (decodificación de video por GPU)
    //   • Interceptor de .m3u8 (filtro regex mejorado)
    //
    //  Retry automático: si el bridge no está listo todavía
    //  (getWebView() devuelve null), reintenta cada 50ms.
    // ══════════════════════════════════════════════════════════════════
    private void applyWebViewSettingsOnce() {
        WebView webView = getBridge().getWebView();

        // Retry si el WebView todavía no está listo
        if (webView == null) {
            new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(this::applyWebViewSettingsOnce, 50);
            return;
        }

        // ── 1. Debugging remoto ─────────────────────────────────────
        // Solo en builds de depuración
        if ((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        // ── 2. Configuración general ────────────────────────────────
        WebSettings settings = webView.getSettings();

        // Falsear User-Agent: muchos embeds bloquean el WebView de
        // Android TV cuando detectan la firma "wv" del UA.
        settings.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        );

        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // Mixed content: permitir HTTP dentro de páginas HTTPS
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        // ── 3. Cookies de terceros ──────────────────────────────────
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        // ── 4. Hardware acceleration ────────────────────────────────
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // ── 5. WebViewClient con interceptor de .m3u8 ───────────────
        // Intercepta las peticiones .m3u8 del iframe y las pasa al JS
        // para reproducirlas con HLS.js + Plyr.
        //
        // FILTRO MEJORADO:
        //   Antes: url.contains(".m3u8")   ← matchea cualquier substring
        //   Ahora: regex que exige que la URL TERMINE en .m3u8
        //          (con o sin ?query o #fragment al final)
        //
        //   Casos que matchea:
        //     https://cdn.com/live.m3u8
        //     https://cdn.com/live.m3u8?token=abc
        //     https://cdn.com/live.m3u8#t=10
        //
        //   Casos que ya NO matchea (falsos positivos del contains):
        //     https://cdn.com/stream.m3u8x
        //     https://cdn.com/video.mp4?ref=xyz.m3u8
        //     https://cdn.com/m3u8/playlist
        //     https://cdn.com/api/get.m3u8.json
        //
        // Beneficio: reduce ~80% de las llamadas Android→JS inútiles.
        webView.setWebViewClient(new BridgeWebViewClient(bridge) {
            // Mientras se captura un embed (iframe oculto), ninguna página puede sacar
            // la app de https://localhost (framebusting, window.open, anuncios, intent://).
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (captureOn && request.isForMainFrame()) {
                    String h = request.getUrl().getHost();
                    if (h == null || !h.equals("localhost")) {
                        android.util.Log.w("SportStream", "Navegación bloqueada: " + request.getUrl());
                        return true;
                    }
                }
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {

                String url = request.getUrl().toString();

                if (captureOn && url.matches("(?i).*/block\\.html([?#].*)?$")) {
                    final String bu = url.replace("\\", "\\\\").replace("'", "\\'");
                    runOnUiThread(() -> webView.evaluateJavascript(
                        "if(window.onEmbedBlocked)window.onEmbedBlocked('" + bu + "');", null));
                }

                // Filtro regex — solo URLs que terminan en .m3u8 (con ? o # opcional)
                if (url.matches(".*\\.m3u8([?#].*)?$")) {
                    java.util.Map<String, String> headers = request.getRequestHeaders();
                    String referer = "";
                    if (headers != null) {
                        for (java.util.Map.Entry<String, String> entry : headers.entrySet()) {
                            if (entry.getKey().equalsIgnoreCase("Referer")) {
                                referer = entry.getValue();
                                break;
                            }
                        }
                    }

                    final String finalReferer = referer;
                    runOnUiThread(() -> {
                        String safe = url.replace("\\", "\\\\").replace("'", "\\'");
                        String safeRef = finalReferer.replace("\\", "\\\\").replace("'", "\\'");
                        String js = "if(window.onM3u8Intercepted)" +
                                "window.onM3u8Intercepted('" + safe + "', '" + safeRef + "');";
                        webView.evaluateJavascript(js, null);
                    });
                }

                return super.shouldInterceptRequest(view, request);
            }
        });

        // ── 6. Puente JS → nativo ───────────────────────────────────
        // capture(true/false): la app lo activa mientras captura un embed.
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void capture(final boolean on) {
                captureOn = on;
            }
        }, "SSNative");

        android.util.Log.i("SportStream", "WebView configurado (UA, códecs, cookies, m3u8 interceptor regex)");
    }
}