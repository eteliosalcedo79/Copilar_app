package com.sportstream.app;

import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends BridgeActivity {

    private volatile boolean captureOn = false;
    private volatile boolean sniffOn = false;   // consola de depuración: reportar peticiones del embed

    private final Map<String, Map<String, String>> hostHeaders = new ConcurrentHashMap<>();
    private static final Pattern HOST_IN_TEXT = Pattern.compile("https?://([^/\\s\"'\\\\?#]+)");
    private static final int MAX_PLAYLIST_BYTES = 2 * 1024 * 1024;
    private static final String PROXY_UA =
        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

    private static String hostOf(String url) {
        try { return new URL(url).getHost().toLowerCase(); } catch (Exception e) { return null; }
    }

    private WebResourceResponse proxyWithHeaders(WebResourceRequest request, Map<String, String> custom) {
        String current = request.getUrl().toString();
        HttpURLConnection conn = null;
        try {
            for (int hop = 0; hop < 6; hop++) {
                conn = (HttpURLConnection) new URL(current).openConnection();
                conn.setInstanceFollowRedirects(false);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(25000);
                conn.setRequestMethod(request.getMethod() != null ? request.getMethod() : "GET");

                Map<String, String> wv = request.getRequestHeaders();
                if (wv != null) {
                    for (Map.Entry<String, String> e : wv.entrySet()) {
                        String k = e.getKey();
                        if (k.equalsIgnoreCase("Range") || k.equalsIgnoreCase("Accept")
                                || k.equalsIgnoreCase("Accept-Language")) {
                            conn.setRequestProperty(k, e.getValue());
                        }
                    }
                }
                conn.setRequestProperty("User-Agent", PROXY_UA);
                conn.setRequestProperty("Accept-Encoding", "identity");
                try {
                    String cookies = CookieManager.getInstance().getCookie(current);
                    if (cookies != null && !cookies.isEmpty()) {
                        conn.setRequestProperty("Cookie", cookies);
                    }
                } catch (Exception ignored) {}
                for (Map.Entry<String, String> e : custom.entrySet()) {
                    conn.setRequestProperty(e.getKey(), e.getValue());
                }

                int code = conn.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = conn.getHeaderField("Location");
                    if (loc == null) break;
                    current = new URL(new URL(current), loc).toString();
                    String h = hostOf(current);
                    if (h != null && !hostHeaders.containsKey(h)) hostHeaders.put(h, custom);
                    conn.disconnect();
                    conn = null;
                    continue;
                }
                break;
            }
            if (conn == null) return null;

            int status = conn.getResponseCode();
            String reason = conn.getResponseMessage();
            if (reason == null || reason.isEmpty()) reason = status < 400 ? "OK" : "Error";
            if (status < 200 || (status >= 300 && status < 400)) return null;

            String contentType = conn.getContentType();
            String mime = "application/octet-stream";
            String enc = null;
            if (contentType != null && !contentType.isEmpty()) {
                String[] p = contentType.split(";");
                mime = p[0].trim();
                for (int i = 1; i < p.length; i++) {
                    String s = p[i].trim();
                    if (s.toLowerCase().startsWith("charset=")) enc = s.substring(8).trim();
                }
            }

            Map<String, String> out = new HashMap<>();
            for (Map.Entry<String, java.util.List<String>> e : conn.getHeaderFields().entrySet()) {
                String k = e.getKey();
                if (k == null || e.getValue() == null || e.getValue().isEmpty()) continue;
                String kl = k.toLowerCase();
                if (kl.equals("content-encoding") || kl.equals("content-length")
                        || kl.equals("transfer-encoding") || kl.equals("connection")
                        || kl.startsWith("access-control-")) continue;
                out.put(k, e.getValue().get(0));
            }
            out.put("Access-Control-Allow-Origin", "*");
            out.put("Access-Control-Expose-Headers", "Content-Length, Content-Range, Content-Type");

            InputStream in = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (in == null) in = new ByteArrayInputStream(new byte[0]);

            String lowerUrl = current.toLowerCase();
            boolean isPlaylist = lowerUrl.matches(".*\\.m3u8([?#].*)?$")
                    || mime.toLowerCase().contains("mpegurl");
            if (isPlaylist && status < 400) {
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] tmp = new byte[16384];
                int n;
                while ((n = in.read(tmp)) > 0 && buf.size() < MAX_PLAYLIST_BYTES) buf.write(tmp, 0, n);
                in.close();
                conn.disconnect();
                byte[] body = buf.toByteArray();
                Matcher m = HOST_IN_TEXT.matcher(new String(body, StandardCharsets.UTF_8));
                while (m.find()) {
                    String h = m.group(1).toLowerCase();
                    int colon = h.indexOf(':');
                    if (colon > 0) h = h.substring(0, colon);
                    if (!hostHeaders.containsKey(h)) hostHeaders.put(h, custom);
                }
                return new WebResourceResponse(mime, enc, status, reason, out, new ByteArrayInputStream(body));
            }

            final HttpURLConnection toClose = conn;
            final InputStream src = in;
            InputStream closing = new InputStream() {
                @Override public int read() throws java.io.IOException { return src.read(); }
                @Override public int read(byte[] b, int off, int len) throws java.io.IOException { return src.read(b, off, len); }
                @Override public void close() throws java.io.IOException {
                    try { src.close(); } finally { toClose.disconnect(); }
                }
            };
            return new WebResourceResponse(mime, enc, status, reason, out, closing);

        } catch (Exception e) {
            android.util.Log.w("SportStream", "Proxy falló: " + current + " → " + e);
            if (conn != null) conn.disconnect();
            Map<String, String> out = new HashMap<>();
            out.put("Access-Control-Allow-Origin", "*");
            return new WebResourceResponse("text/plain", "utf-8", 502, "Bad Gateway", out,
                    new ByteArrayInputStream(new byte[0]));
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(VideoPlayerPlugin.class);
        super.onCreate(savedInstanceState);
        applyWebViewSettingsOnce();
    }

    @Override
    public void onResume() { super.onResume(); }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
            );
        }
    }

    private void applyWebViewSettingsOnce() {
        WebView webView = getBridge().getWebView();
        if (webView == null) {
            new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(this::applyWebViewSettingsOnce, 50);
            return;
        }

        if ((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        WebSettings settings = webView.getSettings();
        settings.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        );
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        webView.setWebViewClient(new BridgeWebViewClient(bridge) {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (captureOn && request.isForMainFrame()) {
                    String h = request.getUrl().getHost();
                    if (h == null || !h.equals("localhost")) {
                        android.util.Log.w("SportStream", "Navegación bloqueada: " + request.getUrl());
                        return true;
                    }
                }
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();

                if (captureOn && url.matches("(?i).*/block\\.html([?#].*)?$")) {
                    final String bu = url.replace("\\", "\\\\").replace("'", "\\'");
                    runOnUiThread(() -> webView.evaluateJavascript(
                        "if(window.onEmbedBlocked)window.onEmbedBlocked('" + bu + "');", null));
                }

                if (captureOn && sniffOn
                        && !url.matches("(?i).*\\.(css|js|png|jpe?g|gif|webp|svg|woff2?|ttf|ico)([?#].*)?$")) {
                    final String su = url.replace("\\", "\\\\").replace("'", "\\'");
                    final String sm = request.getMethod() != null ? request.getMethod() : "GET";
                    runOnUiThread(() -> webView.evaluateJavascript(
                        "if(window.onNetSniff)window.onNetSniff('" + su + "','" + sm + "');", null));
                }

                boolean isHls = url.matches(".*\\.m3u8([?#].*)?$");
                // StreamTape sirve el video desde /get_video (sin extensión)
                boolean isMp4 = url.matches(".*\\.(mp4|mkv|webm)([?#].*)?$")
                        || url.matches("(?i).*/get_video([?#].*)?$");
                if (isHls || isMp4) {
                    java.util.Map<String, String> headers = request.getRequestHeaders();
                    String referer = "";
                    if (headers != null) {
                        for (java.util.Map.Entry<String, String> entry : headers.entrySet()) {
                            if (entry.getKey().equalsIgnoreCase("Referer")) {
                                referer = entry.getValue();
                                break;
                            }
                        }
                    }
                    final String finalReferer = referer;
                    final String cb = isHls ? "onM3u8Intercepted" : "onMp4Intercepted";
                    runOnUiThread(() -> {
                        String safe = url.replace("\\", "\\\\").replace("'", "\\'");
                        String safeRef = finalReferer.replace("\\", "\\\\").replace("'", "\\'");
                        String js = "if(window." + cb + ")window." + cb + "('" + safe + "', '" + safeRef + "');";
                        webView.evaluateJavascript(js, null);
                    });
                }

                if (!hostHeaders.isEmpty() && request.getUrl() != null) {
                    String scheme = request.getUrl().getScheme();
                    String method = request.getMethod();
                    String host = request.getUrl().getHost();
                    if (host != null && ("http".equals(scheme) || "https".equals(scheme))
                            && ("GET".equalsIgnoreCase(method) || "HEAD".equalsIgnoreCase(method))) {
                        Map<String, String> custom = hostHeaders.get(host.toLowerCase());
                        if (custom != null) {
                            WebResourceResponse r = proxyWithHeaders(request, custom);
                            if (r != null) return r;
                        }
                    }
                }

                return super.shouldInterceptRequest(view, request);
            }
        });

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void capture(final boolean on) { captureOn = on; }

            @JavascriptInterface
            public void setHeaders(String url, String json) {
                try {
                    String h = hostOf(url);
                    if (h == null) return;
                    Map<String, String> m = new HashMap<>();
                    if (json != null && !json.isEmpty()) {
                        JSONObject o = new JSONObject(json);
                        Iterator<String> it = o.keys();
                        while (it.hasNext()) {
                            String k = it.next();
                            String v = o.optString(k, "");
                            if (!v.isEmpty()) m.put(k, v);
                        }
                    }
                    hostHeaders.clear();
                    hostHeaders.put(h, m);
                } catch (Exception e) {
                    android.util.Log.w("SportStream", "setHeaders falló: " + e);
                }
            }

            @JavascriptInterface
            public void clearHeaders() { hostHeaders.clear(); }

            @JavascriptInterface
            public void debugSniff(final boolean on) { sniffOn = on; }

            /* Toque simulado en coordenadas CSS del viewport (solo mientras hay captura activa).
               Sirve para pulsar el botón de play dentro del iframe oculto del embed. */
            @JavascriptInterface
            public void tap(final float cssX, final float cssY) {
                if (!captureOn) return;
                runOnUiThread(() -> {
                    try {
                        final float d = getResources().getDisplayMetrics().density;
                        final float x = cssX * d;
                        final float y = cssY * d;
                        final long t = SystemClock.uptimeMillis();
                        MotionEvent down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
                        down.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);
                        webView.dispatchTouchEvent(down);
                        down.recycle();
                        webView.postDelayed(() -> {
                            long t2 = SystemClock.uptimeMillis();
                            MotionEvent up = MotionEvent.obtain(t, t2, MotionEvent.ACTION_UP, x, y, 0);
                            up.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);
                            webView.dispatchTouchEvent(up);
                            up.recycle();
                        }, 60);
                    } catch (Exception e) {
                        android.util.Log.w("SportStream", "tap falló: " + e);
                    }
                });
            }
        }, "SSNative");

        android.util.Log.i("SportStream", "WebView configurado (m3u8+mp4 interceptor, cookies, proxy)");
    }
}