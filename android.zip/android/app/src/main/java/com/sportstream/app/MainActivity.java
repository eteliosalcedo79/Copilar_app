package com.sportstream.app;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;

// Importaciones necesarias para el Proxy
import java.io.InputStream;
import java.net.URL;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class MainActivity extends BridgeActivity {

    private volatile boolean captureOn = false;
    // Cliente HTTP para hacer las peticiones con headers falsos
    private static final OkHttpClient httpClient = new OkHttpClient();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(VideoPlayerPlugin.class);
        super.onCreate(savedInstanceState);
        applyWebViewSettingsOnce();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
            );
        }
    }

    private void applyWebViewSettingsOnce() {
        WebView webView = getBridge().getWebView();

        if (webView == null) {
            new android.os.Handler(android.os.Looper.getMainLooper())
                .postDelayed(this::applyWebViewSettingsOnce, 50);
            return;
        }

        if ((getApplicationInfo().flags & android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        WebSettings settings = webView.getSettings();
        settings.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        );
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.setAcceptThirdPartyCookies(webView, true);
        }

        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        webView.setWebViewClient(new BridgeWebViewClient(bridge) {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (captureOn && request.isForMainFrame()) {
                    String h = request.getUrl().getHost();
                    if (h == null || !h.equals("localhost")) {
                        return true;
                    }
                }
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();

                // 1. Interceptor de pantalla de bloqueo (Se mantiene igual)
                if (captureOn && url.matches("(?i).*/block\\.html([?#].*)?$")) {
                    final String bu = url.replace("\\", "\\\\").replace("'", "\\'");
                    runOnUiThread(() -> webView.evaluateJavascript(
                        "if(window.onEmbedBlocked)window.onEmbedBlocked('" + bu + "');", null));
                }

                // 2. Interceptor de .m3u8 (Se mantiene igual)
                if (url.matches(".*\\.m3u8([?#].*)?$")) {
                    java.util.Map<String, String> headers = request.getRequestHeaders();
                    String referer = "";
                    if (headers != null) {
                        for (java.util.Map.Entry<String, String> entry : headers.entrySet()) {
                            if (entry.getKey().equalsIgnoreCase("Referer")) {
                                referer = entry.getValue();
                                break;
                            }
                        }
                    }
                    final String finalReferer = referer;
                    runOnUiThread(() -> {
                        String safe = url.replace("\\", "\\\\").replace("'", "\\'");
                        String safeRef = finalReferer.replace("\\", "\\\\").replace("'", "\\'");
                        String js = "if(window.onM3u8Intercepted)" +
                                "window.onM3u8Intercepted('" + safe + "', '" + safeRef + "');";
                        webView.evaluateJavascript(js, null);
                    });
                    return super.shouldInterceptRequest(view, request);
                }

                // 3. NUEVO: PROXY NATIVO PARA DOMINIOS BLOQUEADOS (tvf90.com)
                // Si la URL es del dominio problemático, nosotros hacemos la petición.
                if (url.contains("tvf90.com")) {
                    try {
                        // Extraemos el dominio base para el "Disfraz"
                        URL urlObj = new URL(url);
                        String baseUrl = urlObj.getProtocol() + "://" + urlObj.getHost() + "/";
                        
                        // Obtener cookies actuales
                        String cookies = CookieManager.getInstance().getCookie(url);

                        Request.Builder reqBuilder = new Request.Builder()
                                .url(url)
                                .header("Referer", baseUrl)
                                .header("Origin", baseUrl)
                                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");

                        if (cookies != null && !cookies.isEmpty()) {
                            reqBuilder.header("Cookie", cookies);
                        }

                        Response response = httpClient.newCall(reqBuilder.build()).execute();
                        ResponseBody body = response.body();

                        if (body != null) {
                            String contentType = response.header("Content-Type");
                            String mimeType = "text/html";
                            String encoding = "UTF-8";
                            if (contentType != null) {
                                String[] parts = contentType.split(";");
                                mimeType = parts[0].trim();
                                if (parts.length > 1 && parts[1].contains("charset=")) {
                                    encoding = parts[1].split("=")[1].trim();
                                }
                            }
                            // Devolvemos el HTML/JS descargado directamente al WebView
                            InputStream stream = body.byteStream();
                            return new WebResourceResponse(mimeType, encoding, stream);
                        }
                    } catch (Exception e) {
                        android.util.Log.e("SportStream", "Error en proxy nativo para: " + url, e);
                    }
                }

                // Para todo lo demás, dejar que el WebView cargue normal
                return super.shouldInterceptRequest(view, request);
            }
        });

        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void capture(final boolean on) {
                captureOn = on;
            }
        }, "SSNative");
    }
}